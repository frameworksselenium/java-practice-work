package com.example.ageconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgeApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgeApplication.class, args);
	}

}
