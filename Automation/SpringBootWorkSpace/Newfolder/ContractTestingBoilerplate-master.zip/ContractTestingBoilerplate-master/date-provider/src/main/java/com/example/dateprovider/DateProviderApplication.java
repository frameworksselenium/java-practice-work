package com.example.dateprovider;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DateProviderApplication {

	public static void main(String[] args) {
		SpringApplication.run(DateProviderApplication.class, args);
	}

}
